package application.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import application.DTO.ApiResponse;
import application.DTO.AuthenticationRequest;
import application.DTO.AuthenticationResponse;
import application.Util.CommonUtil;
import application.Util.Constant;

@Controller
@RequestMapping("/authenticate")
public class LoginLogoutController {
	
	@Autowired
    private RestTemplate restTemplate; 
	

	
	@RequestMapping(value="/login",method = RequestMethod.POST)
	public String login(HttpServletRequest request){
		String view = "redirect:/admin/new";
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		if(username != null && !username.equals("") && password != null && !password.equals("")) {
			AuthenticationRequest authRequest = new AuthenticationRequest();
			authRequest.setUsername(username);
			authRequest.setPassword(password);
			String url = new String(Constant.BASE_API_URL+Constant.AUTHENTICATION_API_POST_URL);
			
			AuthenticationResponse response = restTemplate.postForObject(url, authRequest, AuthenticationResponse.class);
			if(response != null && response.getJwt() != null){
				HttpSession session = request.getSession();
		    	session.setAttribute(Constant.SESSION_LOGIN_USER_ATTR, response.getUserDto());
		    	session.setAttribute(Constant.SESSION_JWT_TOKEN_ATTR, response.getJwt());
		    	//session.getServletContext().setAttribute("user", response.getUserDto());
		    	
		    	view = "redirect:/index";
			}else {
				view = "redirect:/admin/new?error=true";
			}
		}else{
			view = "redirect:/admin/new?error=true";
		}
	
		return view;
	}
}
