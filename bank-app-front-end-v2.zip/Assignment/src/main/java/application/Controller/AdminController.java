package application.Controller;

import application.DTO.ApiResponse;
import application.DTO.EmployeeDTO;
import application.Service.AdminService;
import application.Service.EmployeeService;
import application.Service.UserService;
import application.Util.CommonUtil;
import application.Util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;


@Controller
@RequestMapping(value = "/admin")
public class AdminController  {
    
	
    
    @Autowired
    private AdminService adminService;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private RestTemplate restTemplate; 
    
    
    @Autowired
    private UserService userService;

    @RequestMapping(value = "new",method = RequestMethod.GET)
    public String showForm(ModelAndView modelAndView) {
        return "admin/new";
    }

    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public String registerUser(HttpServletRequest request) {
        String view = "";


        EmployeeDTO employee = new EmployeeDTO();
        

        if(CommonUtil.isNumber(request.getParameter("salary"))) {
        	String salary = request.getParameter("salary");
        	employee.setSalary(Double.parseDouble(salary));
        	employee.setName(request.getParameter("name"));
        	employee.setPhone(request.getParameter("phone"));
        	employee.setEmail(request.getParameter("email"));
        	employee.setUsername(request.getParameter("username"));
        	employee.setPassword(request.getParameter("password"));
        	employee.setRole(request.getParameter("role"));
        	
        	view = adminService.createEmployee(employee,request);
        	
        }else {
        	view = "redirect:/admin/new?error=true";
        }

    	
    	
        return view;
    }

    @RequestMapping(value = "{id}/edit",method = RequestMethod.GET)
    public String update(@PathVariable long id, Model model,HttpServletRequest request) {
    	String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
        EmployeeDTO employee = employeeService.getEmployeeById(id,token);
        model.addAttribute("employee",employee);
        return "admin/edit";
    }

    @RequestMapping(value = "update",method = RequestMethod.POST)
    public String updateEmployee(HttpServletRequest request) {
        
    	String view = "";
    	
    	EmployeeDTO employee = new EmployeeDTO();
    	
        if(CommonUtil.isNumber(request.getParameter("salary")) && CommonUtil.isNumber(request.getParameter("id"))) {
        	String salary = request.getParameter("salary");
        	employee.setId(Long.parseLong(request.getParameter("id")));
        	employee.setUsername(request.getParameter("username"));
        	employee.setSalary(Double.parseDouble(salary));
        	employee.setName(request.getParameter("name"));
        	employee.setPhone(request.getParameter("phone"));
        	employee.setEmail(request.getParameter("email"));
        	
        	view =  adminService.updateEmployee(employee, request);
        }else {
        	view = "redirect:/admin/new?error=true";
        }
        return view;
    }

    @RequestMapping(value = "/search",method = RequestMethod.GET)
    public String displaySearch(){
        return "admin/search";
    }
    @RequestMapping(value = "/search",method = RequestMethod.POST)
    public String search(HttpServletRequest request) {
    	String url = new String(Constant.BASE_API_URL+Constant.LOG_API_GET_URL);
    	
    	String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
    	Long id = Long.parseLong(request.getParameter("id"));
        EmployeeDTO employee = employeeService.getEmployeeById(id,token);
        String option = request.getParameter("option");
        if(option.equals("VIEW")) {
            return "redirect:/admin/" + employee.getId() + "/view";
        }
        if(option.equals("EDIT")) {
            return "redirect:/admin/" + employee.getId() + "/edit";
        }
        if(option.equals("DELETE")) {
            return "redirect:/admin/" + employee.getId() + "/delete";
        }
        return "redirect:/admin/search";
    }



    @RequestMapping(value = "/{id}/view",method = RequestMethod.GET)
    public String view(@PathVariable long id, Model model,HttpServletRequest request) {
    	String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
    	EmployeeDTO employee = employeeService.getEmployeeById(id,token);
    	List<EmployeeDTO> employees = new ArrayList<EmployeeDTO>();
    	employees.add(employee);
        model.addAttribute("employees",employees);
        return "admin/view";
    }
    


    @RequestMapping(value = "/{id}/delete",method = RequestMethod.GET)
    public String delete(@PathVariable long id) {
        String view = employeeService.deleteEmployee(id);
        return view;
    }

    @RequestMapping(value = "/report",method = RequestMethod.GET)
    public String showForm() {
        return "admin/report";
    }

	/*
	 * @RequestMapping(value = "/report",method = RequestMethod.POST) public
	 * ModelAndView searchEmployee(HttpServletRequest request) throws Exception {
	 * ModelAndView modelAndView = new ModelAndView("admin/showReport"); Long id =
	 * Long.parseLong(request.getParameter("id")); UserDTO user =
	 * userService.getUserByID(id); DateFormat format = new
	 * SimpleDateFormat("yyyy-M-dd"); Date from =
	 * format.parse(request.getParameter("from")); Date to =
	 * format.parse(request.getParameter("to"));
	 * 
	 * List<Log> report = logRepository.findByUserAndTimestampBetween(user,from,to);
	 * modelAndView.addObject("report",report); return modelAndView; }
	 */

    @RequestMapping(value = "/showReport",method = RequestMethod.GET)
    public String showReport() {
        return "admin/showReport";
    }

}
