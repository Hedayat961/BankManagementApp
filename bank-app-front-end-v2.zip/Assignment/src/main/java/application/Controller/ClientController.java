package application.Controller;

import application.DTO.ClientDTO;
import application.Service.ClientService;
import application.Util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/clientOp")
public class ClientController {

	
    @Autowired
    private ClientService clientService;


    @RequestMapping(value = "new", method = RequestMethod.GET)
    public String newClient() {
        return "clientOp/new";
    }

    @RequestMapping(value = "new",method = RequestMethod.POST)
    public String addClient(HttpServletRequest request) {
    	String view = "";
    	
    	try {
	    	ClientDTO client = new ClientDTO();
	    	
	        client.setName(request.getParameter("name"));
	        client.setAddress(request.getParameter("address"));
	        client.setEmail(request.getParameter("email"));
	        client.setCnp(request.getParameter("CNP"));
	        view = clientService.addNewClient(client, request);
    	}catch (Exception e) {
			e.printStackTrace();
		}
        return view;
    }

    @RequestMapping(value = "/{id}/edit",method = RequestMethod.GET)
    public String update(@PathVariable long id, Model model,HttpServletRequest request) {
    	String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
        ClientDTO client = clientService.getClientById(id,token);
        model.addAttribute("client",client);
        return "clientOp/edit";
    }
    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String updateClient(HttpServletRequest request) {
    	String view="";
    	try {
	    	ClientDTO client = new ClientDTO();
	    	client.setId(Long.parseLong(request.getParameter("id")));
	    	client.setName(request.getParameter("name"));
	        client.setAddress(request.getParameter("address"));
	        client.setEmail(request.getParameter("email"));
	        client.setCnp(request.getParameter("CNP"));
	        

	        view = clientService.updateClient(client, request);
    	}catch (Exception e) {
			e.printStackTrace();
			view = "redirect:/clientOp/new?error=true";
		}
        return view;
    }


    @RequestMapping(value = "/{id}/view",method = RequestMethod.GET)
    public String view(@PathVariable long id, Model model,HttpServletRequest request) {
    	String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
        ClientDTO client = clientService.getClientById(id,token);
        model.addAttribute("client",client);
        return "clientOp/view";
    }

    @RequestMapping(value = "/search",method = RequestMethod.GET)
    public String displaySearch(){
        return "clientOp/search";
    }
    @RequestMapping(value = "/search",method = RequestMethod.POST)
    public String search(HttpServletRequest request) {
    	String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
        ClientDTO client = clientService.getClientById(Long.parseLong(request.getParameter("id")),token);
        String option = request.getParameter("option");
        if(option.equals("VIEW")) {
            return "redirect:/clientOp/" + client.getId() + "/view";
        }
        if(option.equals("EDIT")) {
            return "redirect:/clientOp/" + client.getId() + "/edit";
        }
        return "redirect:/clientOp/search";
    }
}
