package application.Controller;

import application.DTO.AccountDTO;
import application.Service.AccountService;
import application.Service.ClientService;
import application.Util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.sql.Date;


@Controller
@RequestMapping("/account")
public class AccountController {


    @Autowired
    private AccountService accountService;
    @Autowired
    private ClientService clientService;

    @RequestMapping(value = "new",method = RequestMethod.GET)
    public String newAccount() {
        return "account/new";
    }

    @RequestMapping(value = "new", method = RequestMethod.POST)
    public String addAccount(HttpServletRequest request) {
    	String view = "";
        try {
        	AccountDTO account = new AccountDTO();
        	account.setBalance(Double.parseDouble(request.getParameter("balance")));
	        account.setDate(new Date(System.currentTimeMillis()));
	        account.setType(request.getParameter("type"));
	        account.setName(request.getParameter("name"));
	        view = accountService.createNewAccount(account, request);
    	}catch (Exception e) {
			e.printStackTrace();
			view = "account/new?error=true";
		}
        return view;
    }

    @RequestMapping(value = "{id}/edit",method = RequestMethod.GET)
    public String update(@PathVariable long id, Model model,HttpServletRequest request) {
    	String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
        AccountDTO account = accountService.getAccountInfoById(id,token);
        model.addAttribute("owner",account.getOwner());
        model.addAttribute("account",account);
        return "account/edit";
    }

    @RequestMapping(value = "update",method = RequestMethod.POST)
    public String updateAccount(HttpServletRequest request) {
    	String view = "";
        AccountDTO account = new AccountDTO();
        account.setId(Long.parseLong(request.getParameter("id")));
        account.setBalance(Double.parseDouble(request.getParameter("balance")));
        account.setType(request.getParameter("type"));
        account.setName(request.getParameter("name"));
        
        try {
        	view = accountService.updateAccount(account, request);
        }catch (Exception e) {
			e.printStackTrace();
			view = "account/new?error=true";
		}

        return view;
    }

    @RequestMapping(value = "/{id}/view",method = RequestMethod.GET)
    public String view(@PathVariable long id, Model model,HttpServletRequest request) {
    	String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
        AccountDTO account = accountService.getAccountInfoById(id,token);
        model.addAttribute("client",account.getOwner());
        model.addAttribute("account",account);
        return "account/view";
    }

    @RequestMapping(value = "/{id}/delete",method = RequestMethod.GET)
    public String delete(@PathVariable long id,HttpServletRequest request) {
    	String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
        accountService.deleteAccount(id, token);
        return "redirect:/index";
    }

    @RequestMapping(value = "/search",method = RequestMethod.GET)
    public String displaySearch(){
        return "account/search";
    }
    @RequestMapping(value = "/search",method = RequestMethod.POST)
    public String search(HttpServletRequest request) {
    	String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
        AccountDTO account = accountService.getAccountInfoById(Long.parseLong(request.getParameter("id")),token);
        String option = request.getParameter("option");
        if(option.equals("VIEW")) {
            return "redirect:/account/" + account.getId() + "/view";
        }
        if(option.equals("EDIT")) {
            return "redirect:/account/" + account.getId() + "/edit";
        }
        if(option.equals("DELETE")) {
            return "redirect:/account/" + account.getId() + "/delete";
        }
        return "redirect:/account/search";
    }


}
