package application.Controller;

import application.DTO.AccountDTO;
import application.Service.AccountService;
import application.Util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.sql.Timestamp;
import java.util.Optional;

@Controller
@RequestMapping("/payment")
public class PaymentController {


    
    @Autowired
    private AccountService accountService;

    @RequestMapping(method = RequestMethod.GET)
    public String show(){
        return "payment";
    }

    @RequestMapping(method = RequestMethod.POST)
    public String process(HttpServletRequest request) {
        String view = "";
        try {
        	String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
	    	AccountDTO account = accountService.getAccountInfoById(Long.parseLong(request.getParameter("id")),token);
	        view = accountService.processBillsTransaction(account,request);
	    /*
        if(validator.validate(account,amount)) {
            account.setBalance(account.getBalance() - amount);
            accountRepository.save(account);
        }
        else
            return "redirect:/payment?error=true";


        Log log = new Log();
        log.setOperation("Utilities payment: Account ID: " + account.getId() + " Amount: " + amount + " Type: " + type);
        log.setTimestamp(new Timestamp(System.currentTimeMillis()));

        String username = request.getRemoteUser();

        Optional<User> user = userRepository.findByUsername(username);
        log.setUser(user.get());

        logRepository.save(log);*/
        }catch (Exception e) {
			e.printStackTrace();
		}
        
        //return "redirect:/index";
        return view;
    }
}
