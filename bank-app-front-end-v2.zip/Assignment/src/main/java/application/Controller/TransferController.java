package application.Controller;

import application.DTO.AccountDTO;
import application.Service.AccountService;
import application.Util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/transfer")
public class TransferController {

	
    
    @Autowired
    private AccountService accountService;

    @RequestMapping(method = RequestMethod.GET)
    public String transfer(){
        return "transfer";
    }
    @RequestMapping(value = "/search",method = RequestMethod.GET)
    public String search(@RequestParam(value = "id1") long id1, @RequestParam(value = "id2") long id2, Model model,HttpServletRequest request) {
    	String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
       
    	
    	AccountDTO from = accountService.getAccountInfoById(id1,token);
        AccountDTO to = accountService.getAccountInfoById(id2,token);
        
        
        model.addAttribute("from",from);
        model.addAttribute("to",to);
        return "transfer/search";
    }

    @RequestMapping(value = "process", method = RequestMethod.POST)
    public String processTransaction(HttpServletRequest request) {
        String view = "";
    	
        try {
        	//TransactionValidator validator = new TransactionValidator();
        	view = accountService.processMoneyTransaction(request);
        }catch (Exception e) {
			e.printStackTrace();
			view = "redirect:/transfer?error=true";
		}
        
        //AccountDTO from = accountRepository.getOne(Long.parseLong(request.getParameter("id1")));
        //AccountDTO to = accountRepository.getOne(Long.parseLong(request.getParameter("id2")));

        /*AccountDTO from = accountService.getAccountInfoById(Long.parseLong(request.getParameter("id1")));
        AccountDTO to = accountRepository.getOne(Long.parseLong(request.getParameter("id2")));

        
        
        validator = new TransactionValidator();
        if(validator.validate(from,amount)) {
            from.setBalance(from.getBalance() - amount);
            to.setBalance(to.getBalance() + amount);

            accountRepository.save(from);
            accountRepository.save(to);
        }
        else
            return "redirect:/transfer?error=true";


        Log log = new Log();
        log.setOperation("Transaction: From " + from.getId() + " To " + to.getId() + " Amount " + amount);
        log.setTimestamp(new Timestamp(System.currentTimeMillis()));

        String username = request.getRemoteUser();

        Optional<User> user = userRepository.findByUsername(username);
        log.setUser(user.get());

        logRepository.save(log);*/

        //return ;
        return view;
    }

}
