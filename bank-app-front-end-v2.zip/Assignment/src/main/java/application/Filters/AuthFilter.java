package application.Filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import application.Util.Constant;



public class AuthFilter implements Filter{
	
	@Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) 
    		throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		
		HttpSession session = req.getSession();
		Object object = session.getAttribute(Constant.SESSION_LOGIN_USER_ATTR);
		if(session.getAttribute(Constant.SESSION_LOGIN_USER_ATTR) != null) {
			chain.doFilter(request, response);
		}else {
			request.getRequestDispatcher("/login").forward(request, response);
		}
		
	}
}
