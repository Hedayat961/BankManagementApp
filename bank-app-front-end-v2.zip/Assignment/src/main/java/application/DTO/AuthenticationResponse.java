package application.DTO;

import java.io.Serializable;


public class AuthenticationResponse implements Serializable{

	private String jwt;
	private UserDTO userDto;

	
	public AuthenticationResponse(String jwt,UserDTO userDto) {
		this.jwt = jwt;
		this.userDto = userDto;
	}
	public AuthenticationResponse() {
		
	}

	public String getJwt() {
		return jwt;
	}

	public UserDTO getUserDto() {
		return userDto;
	}

	public void setUserDto(UserDTO userDto) {
		this.userDto = userDto;
	}
	

}