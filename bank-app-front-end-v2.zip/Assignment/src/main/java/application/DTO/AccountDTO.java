package application.DTO;

import java.util.Date;


public class AccountDTO {

	
    private long id;
    private String type;
    private double balance;
    private String dateStr;
    private Date date;
    private ClientDTO owner;
    private String name;
    
    
    
	public String getDateStr() {
		return dateStr;
	}
	public void setDateStr(String dateStr) {
		this.dateStr = dateStr;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public ClientDTO getOwner() {
		return owner;
	}
	public void setOwner(ClientDTO owner) {
		this.owner = owner;
	}
    
    
    
}
