package application.Util;

import java.util.LinkedHashMap;

import org.springframework.http.HttpHeaders;

import application.DTO.AccountDTO;
import application.DTO.ClientDTO;
import application.DTO.EmployeeDTO;

public class CommonUtil {
	
	public static boolean isNumber(String str) {
		boolean result = true;
		try {
			Double.parseDouble(str);
		}catch (Exception e) {
			e.printStackTrace();
			result = false;
		}
		return result;
	}
	
	public static String getJWTTokenHeaderString(String jwtToken) {
		String bearerValue = "Bearer ";
		String token = bearerValue+jwtToken;
		return token;
	}
	
	public static HttpHeaders getJWTTokenHeader(String jwtToken) {
		HttpHeaders headers = new HttpHeaders();
		headers.set(Constant.AUTH_HEADER_NAME, getJWTTokenHeaderString(jwtToken));
		return headers;
	} 
	
	public static EmployeeDTO fetchObjectEmployeeDTO(LinkedHashMap<String, Object> data) {
		EmployeeDTO employeeDTO = new EmployeeDTO();
		try {
			if(data.containsKey("id") && data.get("id") != null) {
				Integer intValue = (Integer)data.get("id");
				employeeDTO.setId(Long.parseLong(""+intValue));
			}
			
			if(data.containsKey("name") && data.get("name") != null) {
				employeeDTO.setName((String)data.get("name"));
			}
			
			if(data.containsKey("email") && data.get("email") != null) {
				employeeDTO.setEmail((String)data.get("email"));;
			}
			
			if(data.containsKey("phone") && data.get("phone") != null) {
				employeeDTO.setPhone((String)data.get("phone"));;
			}
			
			if(data.containsKey("salary") && data.get("salary") != null) {
				double salary =  (double)data.get("salary");
				employeeDTO.setSalary(salary);
			}
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return employeeDTO;
	}
	
	public static ClientDTO fetchObjectClientDTO(LinkedHashMap<String, Object> data) {
		ClientDTO clientDTO = new ClientDTO();
		try {
			if(data.containsKey("id") && data.get("id") != null) {
				Integer intValue = (Integer)data.get("id");
				clientDTO.setId(Long.parseLong(""+intValue));
			}
			
			if(data.containsKey("name") && data.get("name") != null) {
				clientDTO.setName((String)data.get("name"));
			}
			
			if(data.containsKey("email") && data.get("email") != null) {
				clientDTO.setEmail((String)data.get("email"));;
			}
			
			if(data.containsKey("address") && data.get("address") != null) {
				clientDTO.setAddress((String)data.get("address"));;
			}
			if(data.containsKey("cnp") && data.get("cnp") != null) {
				clientDTO.setCnp((String)data.get("cnp"));;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return clientDTO;
	}
	
	public static AccountDTO fetchObjectAccountDTO(LinkedHashMap<String, Object> data) {
		AccountDTO accountDTO = new AccountDTO();
		try {
			if(data.containsKey("id") && data.get("id") != null) {
				Integer intValue = (Integer)data.get("id");
				accountDTO.setId(Long.parseLong(""+intValue));
			}
			
			if(data.containsKey("name") && data.get("name") != null) {
				accountDTO.setName((String)data.get("name"));
			}
			
			if(data.containsKey("type") && data.get("type") != null) {
				accountDTO.setType((String)data.get("type"));;
			}
			
			if(data.containsKey("balance") && data.get("balance") != null) {
				double balance = (double)data.get("balance");
				accountDTO.setBalance(balance);
			}
			
			if(data.containsKey("dateStr") && data.get("dateStr") != null) {
				accountDTO.setDateStr((String)data.get("dateStr"));
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return accountDTO;
	}

}
