package application.Util;

public class Constant {

	public static final String SESSION_JWT_TOKEN_ATTR = "token";
	public static final String SESSION_LOGIN_USER_ATTR = "user";
	
	
	public static final String AUTH_HEADER_NAME = "Authorization";
	
	public static final String BASE_API_URL = "http://localhost:8084/assignment-api";
	public static final String LOG_API_GET_URL = "/log";
	public static final String AUTHENTICATION_API_POST_URL = "/authenticate";
	public static final String ADMIN_EPLOYEE_URL = "/admin/employee";
	public static final String ADMIN_EPLOYEE_UPDATE_URL = "/admin/employee/update";
	
	public static final String EMPLOYEE_CLIENT_URL = "/client";
	public static final String EMPLOYEE_CLIENT_ACCOUNT_URL = "/client/account";
	public static final String EMPLOYEE_CLIENT_ACCOUNT_UPDATE_URL = "/client/account/update";
	public static final String CLIENT_PAYMENT_ACCOUNT_URL = "/payment/transfer";
	public static final String CLIENT_PAYMENT_BILL_URL = "/payment/process-bills";
	public static final String CLIENT_DELETE_ACCOUNT = "/client/delete/account/";
	
	
}
