package application.Service;

import java.util.List;



import application.DTO.EmployeeDTO;

public interface EmployeeService {

	
	EmployeeDTO getEmployeeById(Long id,String token);
	List<EmployeeDTO> getAllEmployees();
	String deleteEmployee(Long id);
}
