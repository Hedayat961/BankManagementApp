package application.Service;

import javax.servlet.http.HttpServletRequest;

import application.DTO.EmployeeDTO;


public interface AdminService {
	
	String createEmployee(EmployeeDTO employeeDTO,HttpServletRequest request);
	String updateEmployee(EmployeeDTO employeeDTO,HttpServletRequest request);
}
