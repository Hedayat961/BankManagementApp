package application.Service;

import javax.servlet.http.HttpServletRequest;

import application.DTO.AccountDTO;

public interface AccountService {

	
	AccountDTO getAccountInfoById(Long id,String token);
	String createNewAccount(AccountDTO accountDTO, HttpServletRequest request);
	String updateAccount(AccountDTO accountDTO, HttpServletRequest request);
	String processBillsTransaction(AccountDTO accountDTO,HttpServletRequest request);
	String processMoneyTransaction(HttpServletRequest request);
	void deleteAccount(long id,String token);
}
