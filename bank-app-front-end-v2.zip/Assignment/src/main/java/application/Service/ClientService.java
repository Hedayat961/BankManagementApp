package application.Service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import application.DTO.ClientDTO;

public interface ClientService {

	ClientDTO getClientById(Long id,String token);
	List<ClientDTO> getAllClient();
	String addNewClient(ClientDTO clientDTO,HttpServletRequest request);
	String updateClient(ClientDTO clientDTO,HttpServletRequest request);
}
