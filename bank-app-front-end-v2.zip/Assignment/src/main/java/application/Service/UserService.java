package application.Service;

import application.DTO.UserDTO;

public interface UserService {
	
	
	UserDTO getUserByID(Long id);

}
