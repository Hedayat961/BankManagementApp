package application.ServiceImpl;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import application.DTO.ApiResponse;
import application.DTO.EmployeeDTO;
import application.Service.AdminService;
import application.Util.CommonUtil;
import application.Util.Constant;


@Service
public class AdminServiceImpl implements AdminService{
	

    @Autowired
    private RestTemplate restTemplate;
    

	@Override
	public String createEmployee(EmployeeDTO employeeDTO,HttpServletRequest request) {
		String view = null;
		
		try {
			
			String url   = new String(Constant.BASE_API_URL+Constant.ADMIN_EPLOYEE_URL);
			String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
			
	    	HttpEntity<EmployeeDTO> requestEntity = new HttpEntity<EmployeeDTO>(employeeDTO,CommonUtil.getJWTTokenHeader(token));
	    	ApiResponse response = restTemplate.postForObject(url, requestEntity, ApiResponse.class);
	    	if(response != null && response.getStatus().equals("OK")) {
	    		view = "redirect:/index";
	    	}else {
	    		view = "redirect:/admin/new?error=true";
	    	}
              
		}catch (Exception e) {
			e.printStackTrace();
			view = "redirect:/admin/new?error=true";
		}
        
        return view;

	}

	@Override
	public String updateEmployee(EmployeeDTO employeeDTO, HttpServletRequest request) {
		String view = null;
		
		try {
			
			String url   = new String(Constant.BASE_API_URL+Constant.ADMIN_EPLOYEE_UPDATE_URL);
			String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
			
	    	HttpEntity<EmployeeDTO> requestEntity = new HttpEntity<EmployeeDTO>(employeeDTO,CommonUtil.getJWTTokenHeader(token));
	    	ApiResponse response = restTemplate.postForObject(url, requestEntity, ApiResponse.class);
	    	if(response != null && response.getStatus().equals("OK")) {
	    		view = "redirect:/index";
	    	}else {
	    		view = "redirect:/admin/new?error=true";
	    	}
              
		}catch (Exception e) {
			e.printStackTrace();
			view = "redirect:/admin/new?error=true";
		}
        
        return view;

	}
	
	

}
