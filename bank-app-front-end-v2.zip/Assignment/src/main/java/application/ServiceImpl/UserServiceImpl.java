package application.ServiceImpl;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import application.DTO.RoleDTO;
import application.DTO.UserDTO;
import application.Service.UserService;

@Service
public class UserServiceImpl implements UserService {

	
	
	@Override
	public UserDTO getUserByID(Long id) {
		UserDTO userDto = null;
		try {
			/*
			User user = userRepository.getById(id);
			BeanUtils.copyProperties(user, userDto);
			Set<Role> roles = user.getRoles();
			Set<RoleDTO> roleDtoList = new HashSet<RoleDTO>();
			for(Role role:roles) {
				RoleDTO roleDto = new RoleDTO();
				BeanUtils.copyProperties(role, roleDto);
				roleDtoList.add(roleDto);
			}
			userDto.setRoles(roleDtoList);
			*/
		}catch (Exception e) {
			e.printStackTrace();
		}
		return userDto;
	}

}
