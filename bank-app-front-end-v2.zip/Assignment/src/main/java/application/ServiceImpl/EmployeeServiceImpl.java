package application.ServiceImpl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import application.DTO.ApiResponse;
import application.DTO.EmployeeDTO;
import application.Service.EmployeeService;
import application.Util.CommonUtil;
import application.Util.Constant;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	
	@Autowired
    private RestTemplate restTemplate;
	
	@Override
	public EmployeeDTO getEmployeeById(Long id,String token) {
		EmployeeDTO employeeDTO = new EmployeeDTO();
		
		try {
			
			String url   = new String(Constant.BASE_API_URL+Constant.ADMIN_EPLOYEE_URL+"/"+id);
	    	
	    	HttpEntity<Void> requestEntity = new HttpEntity<>(CommonUtil.getJWTTokenHeader(token));
	    	ResponseEntity<ApiResponse> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, ApiResponse.class);
	    	if(response.getBody() != null) {
	    		ApiResponse apiResponse = response.getBody();
	    		employeeDTO = CommonUtil.fetchObjectEmployeeDTO((LinkedHashMap<String, Object>)apiResponse.getObject());
	    	}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return employeeDTO;
	}

	@Override
	public String deleteEmployee(Long id) {
		String view = "redirect:/index";
		try {
			//employeeRepository.deleteById(id);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return view;
	}

	@Override
	public List<EmployeeDTO> getAllEmployees() {
		List<EmployeeDTO> employeeDTOList = new ArrayList<EmployeeDTO>();
		try {
			/*
			List<Employee> employees = employeeRepository.findAll();
			for(Employee emp:employees) {
				EmployeeDTO	employeeDTO = new EmployeeDTO();
				BeanUtils.copyProperties(emp, employeeDTO);
				employeeDTOList.add(employeeDTO);
			}
			*/
		}catch (Exception e) {
			e.printStackTrace();
		}
		return employeeDTOList;
	}

}
