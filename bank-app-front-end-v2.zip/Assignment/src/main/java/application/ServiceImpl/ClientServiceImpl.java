package application.ServiceImpl;

import java.sql.Timestamp;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;


import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import application.DTO.ApiResponse;
import application.DTO.ClientDTO;
import application.Service.ClientService;
import application.Util.CommonUtil;
import application.Util.Constant;

@Service
public class ClientServiceImpl implements ClientService {

    
	
	@Autowired
    private RestTemplate restTemplate;
	
	@Override
	public ClientDTO getClientById(Long id,String token) {
		ClientDTO clientDTO = new ClientDTO();
		
		try {
			
			String url   = new String(Constant.BASE_API_URL+Constant.EMPLOYEE_CLIENT_URL+"/"+id);
	    	
	    	HttpEntity<Void> requestEntity = new HttpEntity<>(CommonUtil.getJWTTokenHeader(token));
	    	ResponseEntity<ApiResponse> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, ApiResponse.class);
	    	if(response.getBody() != null) {
	    		ApiResponse apiResponse = response.getBody();
	    		clientDTO = CommonUtil.fetchObjectClientDTO((LinkedHashMap<String, Object>)apiResponse.getObject());
	    	}

		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return clientDTO;
	}

	@Override
	public List<ClientDTO> getAllClient() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addNewClient(ClientDTO clientDTO,HttpServletRequest request) {
		String view = ""; 
		try{
			
			
			String url   = new String(Constant.BASE_API_URL+Constant.EMPLOYEE_CLIENT_URL);
			String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
			
	    	HttpEntity<ClientDTO> requestEntity = new HttpEntity<ClientDTO>(clientDTO,CommonUtil.getJWTTokenHeader(token));
	    	ApiResponse response = restTemplate.postForObject(url, requestEntity, ApiResponse.class);
			
			if(response != null && response.getStatus().equals("OK")) {
				view = "redirect:/index";
			}else {
				view = "redirect:/clientOp/new?error=true";
			}
		}catch (Exception e) {
			e.printStackTrace();
			view = "redirect:/clientOp/new?error=true";
		}
		return view;
	}

	@Override
	public String updateClient(ClientDTO clientDTO,HttpServletRequest request) {
		String view = ""; 
		try{
			String url   = new String(Constant.BASE_API_URL+Constant.EMPLOYEE_CLIENT_URL);
			String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
			
	    	HttpEntity<ClientDTO> requestEntity = new HttpEntity<ClientDTO>(clientDTO,CommonUtil.getJWTTokenHeader(token));
	    	ApiResponse response = restTemplate.postForObject(url, requestEntity, ApiResponse.class);
			
			if(response != null && response.getStatus().equals("OK")) {
				view = "redirect:/index";
			}else {
				view = "redirect:/clientOp/new?error=true";
			}
			
		}catch (Exception e) {
			e.printStackTrace();
			view = "redirect:/clientOp/new?error=true";
		}
		return view;
	}

}
