package application.ServiceImpl;


import java.sql.Timestamp;
import java.util.LinkedHashMap;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import application.DTO.AccountDTO;
import application.DTO.ApiResponse;
import application.DTO.ClientDTO;
import application.DTO.EmployeeDTO;
import application.Service.AccountService;
import application.Util.CommonUtil;
import application.Util.Constant;


@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
    private RestTemplate restTemplate;

	@Override
	public AccountDTO getAccountInfoById(Long id,String token) {
		AccountDTO accountDTO = new AccountDTO();
		try {
			
			String url   = new String(Constant.BASE_API_URL+Constant.EMPLOYEE_CLIENT_ACCOUNT_URL+"/"+id);
	    	
	    	HttpEntity<Void> requestEntity = new HttpEntity<>(CommonUtil.getJWTTokenHeader(token));
	    	ResponseEntity<ApiResponse> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, ApiResponse.class);
	    	if(response.getBody() != null) {
	    		ApiResponse apiResponse = response.getBody();
	    		accountDTO = CommonUtil.fetchObjectAccountDTO((LinkedHashMap<String, Object>)apiResponse.getObject());
	    	}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return accountDTO;
	}
	
	@Override
	public String createNewAccount(AccountDTO accountDTO, HttpServletRequest request) {
		String view = "";
		try {
			
			String url   = new String(Constant.BASE_API_URL+Constant.EMPLOYEE_CLIENT_ACCOUNT_URL);
			String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
			
	    	HttpEntity<AccountDTO> requestEntity = new HttpEntity<AccountDTO>(accountDTO,CommonUtil.getJWTTokenHeader(token));
	    	ApiResponse response = restTemplate.postForObject(url, requestEntity, ApiResponse.class);
	    	if(response != null && response.getStatus().equals("OK")) {
	    		view = "redirect:/index";
	    	}else {
	    		view = "account/new?error=true";
	    	}

		}catch (Exception e) {
			e.printStackTrace();
			view = "account/new?error=true";
		}
		
		return view;
	}
	
	@Override
	public String updateAccount(AccountDTO accountDTO, HttpServletRequest request) {
		String view = "";
		try {
			
			String url   = new String(Constant.BASE_API_URL+Constant.EMPLOYEE_CLIENT_ACCOUNT_UPDATE_URL);
			String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);
			
	    	HttpEntity<AccountDTO> requestEntity = new HttpEntity<AccountDTO>(accountDTO,CommonUtil.getJWTTokenHeader(token));
	    	ApiResponse response = restTemplate.postForObject(url, requestEntity, ApiResponse.class);
	    	if(response != null && response.getStatus().equals("OK")) {
	    		view = "redirect:/index";
	    	}else {
	    		view = "account/new?error=true";
	    	}

		}catch (Exception e) {
			e.printStackTrace();
			view = "account/new?error=true";
		}
		
		return view;
	}

	@Override
	public String processBillsTransaction(AccountDTO accountDTO,HttpServletRequest request) {
		String view = "";

		try {
			
			Double amount = Double.parseDouble(request.getParameter("amount"));
	        String type = request.getParameter("bill");	
				
			String param = new String("?amount="+amount+"&bill="+type);
				
			String url   = new String(Constant.BASE_API_URL+Constant.CLIENT_PAYMENT_BILL_URL+"/account/"+accountDTO.getId()+param);
			String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);

			HttpEntity<String> requestEntity = new HttpEntity<String>("",CommonUtil.getJWTTokenHeader(token));
			ApiResponse response = restTemplate.postForObject(url, requestEntity, ApiResponse.class,param);
			if(response != null && response.getStatus().equals("OK")) {
				view = "redirect:/index";
			}else {
				view =  "redirect:/payment?error=true";
			}

		}catch (Exception e) {
			e.printStackTrace();
			view =  "redirect:/payment?error=true";
		}

		return view;
	}

	@Override
	public String processMoneyTransaction(HttpServletRequest request) {
		String view = "";
		try {

			Double amount = Double.parseDouble(request.getParameter("amount"));
			String fromId = request.getParameter("id1");
			String toId =request.getParameter("id2");


			String url   = new String(Constant.BASE_API_URL+Constant.CLIENT_PAYMENT_ACCOUNT_URL+"/account/"+fromId+"/account/"+toId+"?amount="+amount);
			String token = (String)request.getSession().getAttribute(Constant.SESSION_JWT_TOKEN_ATTR);

			HttpEntity<String> requestEntity = new HttpEntity<String>("",CommonUtil.getJWTTokenHeader(token));
			ApiResponse response = restTemplate.postForObject(url, requestEntity, ApiResponse.class,"");
			if(response != null && response.getStatus().equals("OK")) {
				view = "redirect:/index";
			}else {
				view =  "redirect:/transfer?error=true";
			}
		}catch (Exception e) {
			e.printStackTrace();
			view = "redirect:/transfer?error=true";
		}
		return view;
	}

	@Override
	public void deleteAccount(long id, String token) {
		
		try {
			String url   = new String(Constant.BASE_API_URL+Constant.CLIENT_DELETE_ACCOUNT+id);
			HttpEntity<String> requestEntity = new HttpEntity<String>("",CommonUtil.getJWTTokenHeader(token));
			restTemplate.delete(url, requestEntity);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	

	

}
