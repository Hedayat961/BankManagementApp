package application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
//import org.springframework.scheduling.annotation.EnableAsync;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.client.RestTemplate;

import application.Filters.AuthFilter;

@SpringBootApplication
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class,args);
    }
    
    
	/*
	 * @Bean public PasswordEncoder getPasswordEncoder() { return new
	 * BCryptPasswordEncoder(); }
	 */
    
    @Bean
    public RestTemplate restTemplate() {
    	return new RestTemplate();
    }
    
    @Bean
    public FilterRegistrationBean<AuthFilter> authFilter(){
        FilterRegistrationBean<AuthFilter> authFilter = new FilterRegistrationBean<>();
        
        authFilter.setFilter(new AuthFilter());
        authFilter.addUrlPatterns("/admin/*","/account/*","/clientOp/*","/payment/*","/transfer/*");
        authFilter.setOrder(2);
        
        return authFilter;
    }
}
