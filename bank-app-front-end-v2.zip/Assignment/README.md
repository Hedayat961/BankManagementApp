### Install instructions
1. Ensure your computer has java installed on it (instructions available here https://java.com/en/download/help/windows_manual_download.xml)
2. Install mysql (https://dev.mysql.com/doc/refman/5.7/en/windows-installation.html)


### How to run & access the application
1. run the Application class in IDE
2. In your browser go to localhost:8080/ and you will be prompted to the login page of the application
3. The following accounts may be used:
    * Username: user
    * Password: user 
  
    * Username: admin
    * Password: admin 


